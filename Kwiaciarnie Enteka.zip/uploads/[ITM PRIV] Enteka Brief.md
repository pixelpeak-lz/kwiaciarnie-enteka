**BRIEF STRONY WWW**

*Kwiaciarnie Enteka | Lublin 2026*

Przygotowany przez In The Making | ITM

*Niniejszy brief wypełniono na podstawie ustalonego zakresu współpracy. Pozycje oznaczone symbolem ⚠ wymagają uzupełnienia lub potwierdzenia przez Klienta przed startem prac.*

| Wariant Basic Landing page – prosty, szybki, mobile-first. Cel: telefon \+ dojazd. | Wariant E-commerce Pełny sklep online – BLIK/PayU, Google Shopping feed, dostawa. |
| :---- | :---- |

# **1\. Strategia i cele biznesowe**

| Pytanie | Odpowiedź / notatka |
| :---- | :---- |
| **Główny cel biznesowy strony** | Basic: generowanie połączeń telefonicznych i wizyt w lokalu od klientów szukających kwiaciarni "na już" w Lublinie.E-commerce: bezpośrednia sprzedaż online z dostawą – automatyzacja zamówień bez konieczności wizyty w lokalu. Podmiot na samym początku maja (04.05.) PayU  |
| **Kluczowe KPI** | Basic: liczba kliknięć w przycisk "Zadzwoń", liczba wyznaczonych tras w Mapach Google, CTR z reklam Google Search.E-commerce: ROAS, koszt zakupu (CPA), współczynnik konwersji sklepu, wartość koszyka, porzucone koszyki. |
| **Ekosystem digital firmy** | Profil Google Business Profile (do skonfigurowania w ramach współpracy), kampanie Google Ads (Search \+ PMax), profile Instagram i Facebook (setup w miesiącu 1). Strona jest centrum całego ekosystemu – wszystkie kampanie prowadzą na LP / sklep. |
| **Produkty,  Dodatki Warianty, Pola** | 15 max. Dodatków: 3 max (świeca, czekolada, list intencyjny/dedykacja) Warianty:  Mały / Średni / Duży z opisami po kliknięciu [https://bukietowa.pl/produkt/fioletowe-fantazje/](https://bukietowa.pl/produkt/fioletowe-fantazje/)  Pola: data, godzina odbioru z wiadomością |
| **Planowana rozbudowa w przyszłości** | **Oferty specjalne: Oferta B2B: Subskrypcja kwiatowa Zlecenia: Dekoracje ślubne Na przeprosiny** |

# **2\. USP i wyróżniki marki**

| Pytanie | Odpowiedź / notatka |
| :---- | :---- |
| **Co wyróżnia markę na tle konkurencji?** | Produkty pierwszej jakości 30+ lat doświadczenia Abonament kwiatowy  Parking |
| **Kluczowe wartości marki** | premium-dostępne (nie budżetowe, nie ultra-luksus), odważne i wyraziste, ciepłe i ludzkie, profesjonalne z naciskiem na jakość |
| **Główne przewagi konkurencyjne** | **Bezpośrednio od producenta, nie od hurtowni Gotowe pakiety prezentowe** |
| **Specjalne oferty / promocje na start** | (a) rabat \-10% lub  (b) prezent dodatkowy |
| **Elementy oferty do najmocniejszego zaakcentowania** | Na podstawie zakresu kampanii: bukiety ślubne, flowerbox z dostawą, kompozycje na rocznicę, kwiaty z dowozem na telefon Lublin. |

# **3\. Grupa docelowa i ścieżka użytkownika**

## **Persony docelowe**

| Persona A – Spontaniczny | Persona B – Planujący okazję | Persona C – Organizator eventów |
| :---- | :---- | :---- |
| Mężczyzna / kobieta 18–50+ lat, Lublin i okolice. Szuka kwiaciarni "na teraz" – z jakiejkolwiek okolicy. Zakres geogr.: Przed Świdnikiem, ok. 30+ km Główny kanał: Google Search \+ Google Maps. | Osoba 18-50 lat planująca, imieniny, urodziny,  ślub, lub kondolencje.  Kanały: Google Search, Instagram, strona www. | Firma / hotel / restauracja szukająca regularnych dostaw lub dekoracji na event. Zależy na fakturze VAT i sprawnej realizacji. Kanał: Google Search, strona www (formularz). |

| Pytanie | Odpowiedź / notatka |
| :---- | :---- |
| **Ścieżka użytkownika – Basic** | Reklama Google Search / PMax → Landing page → przycisk "Zadzwoń" lub "Wyznacz trasę" → konwersja. Ścieżka maksymalnie krótka – zero rozpraszaczy. |
| **Ścieżka użytkownika – E-commerce** | Reklama Google Search / Shopping → strona produktu → dodanie do koszyka → checkout (BLIK/PayU) → potwierdzenie zamówienia e-mail/SMS → dostawa. Ścieżka zoptymalizowana pod mobile. |
| **Punkty styku z marką przed wizytą na stronie** | Google Maps / GBP (pinezka lokalu), reklamy Google Search i PMax, posty organiczne na Instagramie i Facebooku, opinie Google. |

# **4\. UX/UI i design**

## **Architektura strony – Wariant E-commerce**

| Sekcja / podstrona | Zawartość / cel |
| :---- | :---- |
| **Strona główna** | Hero z 3 banerami, okazjami, bestsellery, tekstem o sklepie, opinie |
| **Sklep / kategorie** | Bukiety, flowerbox, kondolencje, ślubne, filtry okazji |
| **Strona produktu** | Galeria, opis, rozmiar, cena, dostępność, przycisk "Dodaj do koszyka" |
| **Koszyk i checkout** | BLIK, PayU, karta – płatności online; wybór daty i strefy dostawy tutaj ważne aby były propozycje upsellu Różne opcje dostawy: odbiór w sklepie (osobista), z terminem (data, godzina) wysyłka (dopłata) |
| **O nas (sekcja na str. głównej)** | Historia, zespół, filozofia, lokalizacja |
| **Kontakt** | Formularz \+ mapa \+ dane \+ godziny |
| **Blog (opcja)** | Artykuły o pielęgnacji kwiatów, trendach – wsparcie SEO |

| Pytanie | Odpowiedź / notatka |
| :---- | :---- |
| **Wytyczne brandingowe / design system** | **Biały / złoty / beż / amarant, ewentualnie jaśniejszy khaki jako zielony**  Przystępna \> bardziej niż Premium / ekskluzywna Lekka \> poważna  Znacznie bardziej Ciepła / ludzka \> Chłodna / korporacyjna Emocjonalna \> Racjonalna / funkcjonalna Bardziej Odważna / wyrazista \> Stonowana / subtelna Profesjonalizm i rzetelność  |
| **Przykłady stron, które się podobają** | **Antyprzykład: [link](https://www.elizaflowers.pl/en?gad_source=1&gad_campaignid=23086304317&gbraid=0AAAAACNUNS7WgsbmszKGIOXEwXvo15u01)** Bardziej jak [bukietowa.pl](http://bukietowa.pl)  |

# **5\. Wdrożenie i rozwój**

| Pytanie | Odpowiedź / notatka |
| :---- | :---- |
| **Preferowany harmonogram** | Brief i kickoff: 1 dzień po zatwierdzeniu oferty.Konspekt w Figma: do 5 dni roboczych.Projekt wizualny: do 10 dni roboczych od akceptacji Figma.Wdrożenie: do 7 dni roboczych od akceptacji projektu.Start kampanii: do 3 dni roboczych po uruchomieniu strony. |
| **Kto dostarcza treści (copy)?** | **ITM** |
| **Kto dostarcza zdjęcia?** | **Do kiedy?** |
| **Proces akceptacji** | 1\. Akceptacja konspektu (Figma) – max 5 dni roboczych na feedback. 2\. Akceptacja projektu wizualnego – do 2 rund poprawek w cenie. 3\. Akceptacja wdrożenia |
| **Dokumentacja techniczna** | Przekazanie dostępów: hosting, domena, CMS (WordPress / WooCommerce), konto Google Analytics, GTM, Google Ads, Merchant Center. Dokumentacja wdrożeniowa dostępna na życzenie. |

# **6\. Aspekty prawne i formalne**

| Pytanie | Odpowiedź / notatka |
| :---- | :---- |
| **Wymagane certyfikaty / zgodności** | **dostarczy ITM** |
| **Polityka prywatności i RODO** | **dostarczy ITM** |
| **Regulamin sklepu (E-commerce)** | **sporządzi ITM** |
| **Prawa autorskie do materiałów** | Klient oświadcza, że dostarczone materiały (zdjęcia, logotypy, treści) są wolne od roszczeń osób trzecich lub przekazuje stosowne licencje. Zdjęcia stockowe dokupione przez ITM posiadają licencję komercyjną. |
| **Dane do faktury / umowy** | **⚠** *Do uzupełnienia: pełna nazwa firmy, NIP, adres siedziby, dane osoby kontaktowej, preferowana forma płatności i termin.* |

# **Kolejne kroki**

Na podstawie powyższego briefu rekomendujemy następujące działania przed kickoff meetingiem:

Jasne, tu masz wszystko do przeklejenia bezpośrednio:

---

## **🌸 ENTEKA FLOWERS – SPECYFIKACJA PRODUKTÓW**

**Termin dostarczenia: max. 21 maja 2026**

---

### **SEKCJA A – BUKIETY**

**Rozmiar MAŁY**

| Nr | Nazwa produktu | Skład / opis (kwiaty, ilość szt.) | Cena brutto (zł) | Zdjęcie (TAK/NIE) |
| ----- | ----- | ----- | ----- | ----- |
| 1 |  |  |  |  |
| 2 |  |  |  |  |
| 3 |  |  |  |  |
| 4 |  |  |  |  |

Opis rozmiaru MAŁY (np. "ok. 15–20 łodyg, idealne na co dzień"):

**Rozmiar ŚREDNI**

| Nr | Nazwa produktu | Skład / opis (kwiaty, ilość szt.) | Cena brutto (zł) | Zdjęcie (TAK/NIE) |
| ----- | ----- | ----- | ----- | ----- |
| 5 |  |  |  |  |
| 6 |  |  |  |  |
| 7 |  |  |  |  |
| 8 |  |  |  |  |

Opis rozmiaru ŚREDNI (np. "ok. 25–30 łodyg, na wyjątkowe okazje"):

**Rozmiar DUŻY**

| Nr | Nazwa produktu | Skład / opis (kwiaty, ilość szt.) | Cena brutto (zł) | Zdjęcie (TAK/NIE) |
| ----- | ----- | ----- | ----- | ----- |
| 9 |  |  |  |  |
| 10 |  |  |  |  |
| 11 |  |  |  |  |
| 12 |  |  |  |  |

Opis rozmiaru DUŻY (np. "ok. 40+ łodyg, premium na śluby i jubileusze"):

---

### **SEKCJA B – FLOWER BOXY**

| Nr | Nazwa pakietu | Dokładny skład (producent / wariant) | Cena brutto (zł) | Zdjęcie (TAK/NIE) | Uwagi |
| ----- | ----- | ----- | ----- | ----- | ----- |
| 13 | Kwiaty \+ miś \+ maseczki |  |  |  |  |
| 14 | Kwiaty \+ czekolada |  |  |  |  |
| 15 | Kwiaty \+ makaroniki |  |  |  | ⚠ wymaga Sanepid |

Czy klient może personalizować zawartość boxu (np. kolor kwiatów)? TAK / NIE:

Czy box ma opakowanie z brandingiem Enteka? TAK / NIE / W planach:

---

### **SEKCJA C – DODATKI DO BUKIETÓW (max. 3\)**

| Nr | Nazwa dodatku | Opis (marka / wariant) | Cena brutto (zł) | Zdjęcie (TAK/NIE) |
| ----- | ----- | ----- | ----- | ----- |
| D1 | Świeca zapachowa |  |  |  |
| D2 | Czekolada |  |  |  |
| D3 |  |  |  |  |

---

### **SEKCJA D – DANE TECHNICZNE SKLEPU**

| Pytanie | Odpowiedź |
| ----- | ----- |
| Dostępne strefy dostawy (dzielnice / miasta) |  |
| Stawka dostawy (zł) |  |
| Darmowa dostawa od kwoty (zł) |  |
| Czas realizacji (od złożenia zamówienia) |  |
| Adres lokalu |  |
| Godziny otwarcia pon–pt |  |
| Godziny otwarcia sob |  |
| Godziny otwarcia niedz |  |
| Możliwość wyboru daty dostawy przez klienta? (TAK/NIE) |  |
| Możliwość wyboru godziny dostawy? (TAK/NIE) |  |
| Pole "Dedykacja / wiadomość na karteczce"? (TAK/NIE) |  |
| Pole NIP przy zamówieniu (do faktury)? (TAK/NIE) |  |

---

### **SEKCJA E – PROMOCJA NA OTWARCIE**

| Pytanie | Odpowiedź |
| ----- | ----- |
| Wybrana opcja (po analizie Excela) | Opcja A / Opcja B / Inna |
| Opcja A – Rabat \-10% na pierwsze zamówienie |  |
| Opcja B – Prezent dodatkowy (Merci) do pierwszych \_\_ zamówień |  |
| Kod rabatowy (jeśli dotyczy) |  |
| Czas trwania promocji (od–do) |  |

---

### **SEKCJA F – DANE FIRMY**

| Pytanie | Odpowiedź |
| ----- | ----- |
| Pełna nazwa firmy |  |
| NIP |  |
| Adres siedziby |  |
| Adres lokalu (jeśli inny) |  |
| E-mail kontaktowy (widoczny na stronie) |  |
| Telefon kontaktowy (widoczny na stronie) |  |
| Numer konta bankowego (do zwrotów) |  |
| Bramka płatności (Łukasz / Marcin / inna) |  |

---

### **SEKCJA G – CHECKLIST ZDJĘĆ *(termin: max. 21 maja)***

*Wymagania: JPG/PNG | min. 1500×1500 px | tło białe lub neutralne | min. 2–3 ujęcia na produkt*

| Nr | Produkt | Zdjęcia gotowe? (TAK/NIE) | Data dostarczenia |
| ----- | ----- | ----- | ----- |
| 1 | Bukiet mały – wariant A |  |  |
| 2 | Bukiet mały – wariant B |  |  |
| 3 | Bukiet mały – wariant C |  |  |
| 4 | Bukiet mały – wariant D |  |  |
| 5 | Bukiet średni – wariant A |  |  |
| 6 | Bukiet średni – wariant B |  |  |
| 7 | Bukiet średni – wariant C |  |  |
| 8 | Bukiet średni – wariant D |  |  |
| 9 | Bukiet duży – wariant A |  |  |
| 10 | Bukiet duży – wariant B |  |  |
| 11 | Bukiet duży – wariant C |  |  |
| 12 | Bukiet duży – wariant D |  |  |
| 13 | Flower Box – miś \+ maseczki |  |  |
| 14 | Flower Box – czekolada |  |  |
| 15 | Flower Box – makaroniki |  |  |
| D1 | Dodatek – świeca |  |  |
| D2 | Dodatek – czekolada |  |  |
| D3 | Dodatek – \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |  |  |

---

*Dokument przygotowany przez In The Making | ITM | inthemaking.pl*

* Klient potwierdza lub uzupełnia pozycje oznaczone ⚠

* Klient dostarcza: logo (wektory), przykłady stron, wytyczne brandingowe, zdjęcia

* Klient wskazuje osobę odpowiedzialną za akceptację kolejnych etapów

* Kickoff meeting – omówienie harmonogramu i finalny zakres

* Start prac po podpisaniu umowy / zatwierdzeniu oferty

*Brief przygotowany przez In The Making | ITM*